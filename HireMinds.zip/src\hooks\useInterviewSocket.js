import { useEffect, useRef, useState, useCallback } from "react";

export default function useInterviewSocket(websocketUrl) {
  const socketRef = useRef(null);
  const didConnectRef = useRef(false); // prevent double-connect in StrictMode

  const [connected, setConnected] = useState(false);
  const [messages, setMessages] = useState([]);
  const [phase, setPhase] = useState("intro");
  const [isAiSpeaking, setIsAiSpeaking] = useState(false);

  const addAiMessage = useCallback((text, state, questionIndex) => {
    setMessages((prev) => [
      ...prev,
      {
        role: "ai",
        text,
        state: state || "",
        questionIndex: questionIndex ?? null,
        time: new Date().toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        }),
      },
    ]);
  }, []);

  useEffect(() => {
    if (!websocketUrl) return;
    if (didConnectRef.current) return; // ✅ منع double connect
    didConnectRef.current = true;

    console.log("[WS] Connecting to:", websocketUrl);
    const ws = new WebSocket(websocketUrl);
    ws.binaryType = "arraybuffer";
    socketRef.current = ws;

    ws.onopen = () => {
      console.log("[WS] Connected ✅");
      setConnected(true);
    };

    ws.onclose = (e) => {
      console.log("[WS] Closed:", e.code, e.reason);
      setConnected(false);
    };

    ws.onerror = (e) => {
      console.error("[WS] Error:", e);
    };

    ws.onmessage = (event) => {
      // Binary = TTS audio (نتجاهله لو الـ TTS مش شغال على السيرفر)
      if (event.data instanceof ArrayBuffer) return;

      let msg;
      try {
        msg = JSON.parse(event.data);
      } catch {
        return;
      }

      console.log("[WS] ←", msg.type, msg);

      switch (msg.type) {
        case "intro":
        case "question":
        case "followup":
        case "clarification":
        case "close":
          addAiMessage(msg.text, msg.state, msg.question_index);
          if (msg.state) setPhase(msg.state.toLowerCase());
          // TTS error على السيرفر → نخلي الـ speaking false فوراً
          setIsAiSpeaking(false);
          break;

        case "tts_start":
          setIsAiSpeaking(true);
          break;

        case "tts_end":
          // لو فيه error في الـ TTS على السيرفر، نعمل speaking = false
          setIsAiSpeaking(false);
          break;

        case "complete":
          setPhase("complete");
          ws.close(1000, "Interview completed");
          break;

        case "error":
          console.error("[WS] Server error:", msg.message);
          addAiMessage(`⚠️ ${msg.message}`, "ERROR", null);
          setIsAiSpeaking(false);
          break;

        default:
          console.warn("[WS] Unknown type:", msg.type);
      }
    };

    return () => {
      ws.close();
    };
  }, [websocketUrl, addAiMessage]);

  const sendTextAnswer = useCallback((text) => {
    const ws = socketRef.current;
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    ws.send(JSON.stringify({ type: "answer", text }));
  }, []);

  const sendAudioAnswer = useCallback(async (audioBlob) => {
    const ws = socketRef.current;
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    ws.send(JSON.stringify({ type: "answer_audio" }));
    const buffer = await audioBlob.arrayBuffer();
    ws.send(buffer);
  }, []);

  const endSession = useCallback(() => {
    const ws = socketRef.current;
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    ws.send(JSON.stringify({ type: "end_session" }));
  }, []);

  return {
    connected,
    messages,
    phase,
    isAiSpeaking,
    sendTextAnswer,
    sendAudioAnswer,
    endSession,
    socket: socketRef.current,
  };
}

// import { useEffect, useRef, useState, useCallback } from "react";

// /**
//  * useInterviewSocket — connects to AI Interviewer WebSocket
//  *
//  * Handles:
//  *  - JSON text frames: intro, question, followup, clarification,
//  *                      close, complete, tts_start, tts_end, error
//  *  - Binary frames (Blob): TTS audio chunks between tts_start / tts_end
//  */
// export default function useInterviewSocket(websocketUrl) {
//   const socketRef = useRef(null);
//   const audioContextRef = useRef(null);
//   const audioChunksRef = useRef([]); // ArrayBuffers collected during TTS
//   const isReceivingAudioRef = useRef(false);

//   const [connected, setConnected] = useState(false);
//   const [messages, setMessages] = useState([]);
//   const [phase, setPhase] = useState("intro");
//   const [isAiSpeaking, setIsAiSpeaking] = useState(false);

//   const addAiMessage = useCallback((text, state, questionIndex) => {
//     setMessages((prev) => [
//       ...prev,
//       {
//         role: "ai",
//         text,
//         state: state || "",
//         questionIndex: questionIndex ?? null,
//         time: new Date().toLocaleTimeString([], {
//           hour: "2-digit",
//           minute: "2-digit",
//         }),
//       },
//     ]);
//   }, []);

//   // Play all collected audio chunks as one buffer
//   const playAudioQueue = useCallback(async (chunks) => {
//     if (!chunks.length) return;
//     try {
//       if (!audioContextRef.current) {
//         audioContextRef.current = new (
//           window.AudioContext || window.webkitAudioContext
//         )();
//       }
//       const ctx = audioContextRef.current;

//       // Resume context if suspended (browser autoplay policy)
//       if (ctx.state === "suspended") await ctx.resume();

//       const totalLength = chunks.reduce((s, c) => s + c.byteLength, 0);
//       const combined = new Uint8Array(totalLength);
//       let offset = 0;
//       for (const chunk of chunks) {
//         combined.set(new Uint8Array(chunk), offset);
//         offset += chunk.byteLength;
//       }

//       const audioBuffer = await ctx.decodeAudioData(combined.buffer);
//       const source = ctx.createBufferSource();
//       source.buffer = audioBuffer;
//       source.connect(ctx.destination);
//       source.onended = () => setIsAiSpeaking(false);
//       source.start();
//       setIsAiSpeaking(true);
//     } catch (err) {
//       console.warn("[WS] Audio playback error:", err);
//       setIsAiSpeaking(false);
//     }
//   }, []);

//   useEffect(() => {
//     if (!websocketUrl) return;

//     console.log("[WS] Connecting to:", websocketUrl);
//     const ws = new WebSocket(websocketUrl);

//     // ✅ Tell the browser to give us ArrayBuffer for binary frames
//     // (not Blob) so we can pass them directly to decodeAudioData
//     ws.binaryType = "arraybuffer";

//     socketRef.current = ws;

//     ws.onopen = () => {
//       console.log("[WS] Connected ✅");
//       setConnected(true);
//     };

//     ws.onclose = (e) => {
//       console.log("[WS] Closed:", e.code, e.reason);
//       setConnected(false);
//     };

//     ws.onerror = (e) => {
//       console.error("[WS] Error:", e);
//     };

//     ws.onmessage = (event) => {
//       // ── Binary frame = TTS audio chunk ───────────────────────
//       if (event.data instanceof ArrayBuffer) {
//         if (isReceivingAudioRef.current) {
//           audioChunksRef.current.push(event.data);
//         }
//         return;
//       }

//       // ── Text frame = JSON ─────────────────────────────────────
//       let msg;
//       try {
//         msg = JSON.parse(event.data);
//       } catch {
//         console.warn("[WS] Non-JSON text frame ignored:", event.data);
//         return;
//       }

//       console.log("[WS] ←", msg.type, msg);

//       switch (msg.type) {
//         case "intro":
//         case "question":
//         case "followup":
//         case "clarification":
//         case "close":
//           addAiMessage(msg.text, msg.state, msg.question_index);
//           if (msg.state) setPhase(msg.state.toLowerCase());
//           break;

//         case "tts_start":
//           audioChunksRef.current = [];
//           isReceivingAudioRef.current = true;
//           break;

//         case "tts_end":
//           isReceivingAudioRef.current = false;
//           playAudioQueue([...audioChunksRef.current]);
//           audioChunksRef.current = [];
//           break;

//         case "complete":
//           setPhase("complete");
//           ws.close(1000, "Interview completed");
//           break;

//         case "error":
//           console.error("[WS] Server error:", msg.message);
//           addAiMessage(`⚠️ ${msg.message}`, "ERROR", null);
//           break;

//         default:
//           console.warn("[WS] Unknown type:", msg.type);
//       }
//     };

//     return () => {
//       ws.close();
//       socketRef.current = null;
//     };
//   }, [websocketUrl, addAiMessage, playAudioQueue]);

//   // ── Send helpers ──────────────────────────────────────────────

//   const sendTextAnswer = useCallback((text) => {
//     const ws = socketRef.current;
//     if (!ws || ws.readyState !== WebSocket.OPEN) return;
//     ws.send(JSON.stringify({ type: "answer", text }));
//   }, []);

//   const sendAudioAnswer = useCallback(async (audioBlob) => {
//     const ws = socketRef.current;
//     if (!ws || ws.readyState !== WebSocket.OPEN) return;
//     ws.send(JSON.stringify({ type: "answer_audio" }));
//     const buffer = await audioBlob.arrayBuffer();
//     ws.send(buffer);
//   }, []);

//   const endSession = useCallback(() => {
//     const ws = socketRef.current;
//     if (!ws || ws.readyState !== WebSocket.OPEN) return;
//     ws.send(JSON.stringify({ type: "end_session" }));
//   }, []);

//   return {
//     connected,
//     messages,
//     phase,
//     isAiSpeaking,
//     sendTextAnswer,
//     sendAudioAnswer,
//     endSession,
//     socket: socketRef.current,
//   };
// }
