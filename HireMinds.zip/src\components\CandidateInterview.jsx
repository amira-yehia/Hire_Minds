import { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import CandidateSidebar from "./CandidateSidebar";
import InterviewRoom from "./InterviewRoom";
import FaceVerify from "./FaceVerify";
import { aiInterviewAPI, getSession } from "../api";
// import { interviewAPI, getSession } from "../api";
// const DEMO_WS_URL =
//   "wss://doaa-helmy-interviewer2.hf.space/ws/interview/3b6d2c9f-84a5-43f0-bef3-1c89f5d8a7e4";

export default function CandidateInterview() {
  const navigate = useNavigate();
  const [phase, setPhase] = useState("verify");
  const [sessionId, setSessionId] = useState(null);
  const [websocketUrl, setWebsocketUrl] = useState(null);
  const [loading, setLoading] = useState(false);

  const prepareInterview = async () => {
    try {
      setLoading(true);

      const session = getSession();

      const payload = {
        session_id: crypto.randomUUID(),
        candidate_name: session?.fullName || "Candidate",
        job_role: "Frontend Developer",
        level: "Junior",
        duration_limit: 1800,
        questions: [
          {
            question: "Tell me about yourself",
            golden_answer: "",
            skill: "Communication",
            rationale: "",
            time_limit_seconds: 120,
          },
        ],
      };
      // const result = await aiInterviewAPI.prepare(payload);
      // const result = await interviewAPI.prepare(payload);
      // console.log("PREPARE RESULT", result);
      const result = await aiInterviewAPI.prepare(payload);

      console.log("PREPARE", result);

      setSessionId(result.session_id);
      setWebsocketUrl(aiInterviewAPI.wsUrl(result.session_id));
      // setSessionId(result.session_id);
      // setWebsocketUrl(result.websocket_url);
      setWebsocketUrl(
        `wss://doaa-helmy-interviewer2.hf.space/ws/interview/${result.session_id}`,
      );

      setPhase("started");
    } catch (err) {
      console.error(err);
      alert(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleInterviewFinish = () => {
    localStorage.setItem("interviewCompleted", "true");
    setPhase("completed");
  };

  if (phase === "verify") {
    return (
      <div className="candidate-shell">
        <CandidateSidebar />
        <main className="candidate-main">
          <header className="candidate-topbar">
            <div>
              <h1>AI Interview</h1>
              <p>Step 1 of 2 — Identity Verification</p>
            </div>
          </header>
          <section className="candidate-view">
            <FaceVerify onVerified={() => setPhase("ready")} />
          </section>
        </main>
      </div>
    );
  }

  if (phase === "ready") {
    return (
      <div className="candidate-shell">
        <CandidateSidebar />
        <main className="candidate-main">
          <header className="candidate-topbar">
            <div>
              <h1>AI Interview</h1>
              <p>Step 2 of 2 — Start Interview</p>
            </div>
          </header>
          <section className="candidate-view">
            <article className="candidate-profile-card">
              <p
                style={{
                  color: "#16a34a",
                  fontWeight: 600,
                  marginBottom: "1rem",
                }}
              >
                ✅ Identity verified successfully!
              </p>
              <h2>Ready to Start</h2>
              <p>
                Microphone access is required. Make sure you're in a quiet
                environment.
              </p>
              {/* <button
                className="candidate-wide-button"
                onClick={() => setPhase("started")}
                style={{ marginTop: "1.5rem" }}
              >
                Start Interview
              </button> */}
              <button
                className="candidate-wide-button"
                onClick={prepareInterview}
              >
                {loading ? "Preparing..." : "Start Interview"}
              </button>
            </article>
          </section>
        </main>
      </div>
    );
  }

  if (phase === "completed") {
    return (
      <div className="candidate-shell">
        <CandidateSidebar />
        <main className="candidate-main">
          <div className="candidate-profile-card">
            <h1>✅ Interview Completed</h1>
            <p>Thank you! Your results will be reviewed by the HR team.</p>
            <button
              className="candidate-wide-button"
              onClick={() => navigate("/candidate")}
              style={{ marginTop: "1.5rem" }}
            >
              Back To Dashboard
            </button>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="candidate-shell">
      <CandidateSidebar />
      <main className="candidate-main">
        {/* <InterviewRoom
          websocketUrl={DEMO_WS_URL}
          onFinish={handleInterviewFinish}
        /> */}
        <InterviewRoom
          sessionId={sessionId}
          websocketUrl={websocketUrl}
          onFinish={handleInterviewFinish}
        />
      </main>
    </div>
  );
}
